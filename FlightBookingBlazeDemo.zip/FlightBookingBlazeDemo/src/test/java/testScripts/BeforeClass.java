package testScripts;

public @interface BeforeClass {

}
